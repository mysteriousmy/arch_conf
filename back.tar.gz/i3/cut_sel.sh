scrot -s -b -m -e 'xclip -selection clipoard -t "image/png" $f && mv $f ~/Pictures/ScreenShortcut/%Y-%m-%d_%H:%m_select.png'

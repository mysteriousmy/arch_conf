#!/bin/bash
while true
do
  feh --randomize --bg-fill ~/Pictures/wallpaper/
  sleep 1h
done
